﻿using Elars.CsvToSql.Core;
using System;
using System.Windows;

namespace Elars.CsvToSql.UI
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
        private async void btnFromClipboard_Click(object sender, RoutedEventArgs e)
        {
            if (!Clipboard.ContainsText())
            {
                MessageBox.Show("Clipboard does not contain text");
                return;
            }

            try
            {
                var converter = new Converter
                {
                    Options = GetOptions()
                };

                txtSql.Text = await converter.ProcessString(Clipboard.GetText());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private Options GetOptions()
        {
            var options = new Options();
            options.TableName = txtTableName.Text;
            options.CreateTable = chkCreateTable.IsChecked.Value;
            options.Reseed = chkReseed.IsChecked.Value;
            options.NoCount = chkNoCount.IsChecked.Value;
            options.AllowSpaces = chkAllowSpaces.IsChecked.Value;
            options.ClusteredIndex = radClustered.IsChecked.Value;
            options.IdentityInsert = chkIdentityInsert.IsChecked.Value;

            return options;
        }

        private void btnToClipboard_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(txtSql.Text);
        }
    }
}
