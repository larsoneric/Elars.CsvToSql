﻿using Elars.CsvToSql.Core.Extensions;
using Sylvan.Data.Csv;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elars.CsvToSql.Core
{
    public class Converter
    {
        public Options Options { get; set; }

        public async Task<string> ProcessFile(string csvFilePath)
        {
            if (!File.Exists(csvFilePath))
            {
                throw new FileNotFoundException();
            }

            var text = await File.ReadAllTextAsync(csvFilePath);
            return await ProcessString(text);
        }

        public async Task<string> ProcessString(string csvText)
        {
            if (string.IsNullOrWhiteSpace(Options.TableName))
            {
                throw new Exception("Table name is required");
            }

            var csv = await CsvDataReader.CreateAsync(new StringReader(csvText));
            if (csv == null || !csv.HasRows)
            {
                throw new Exception("Data was empty");
            }

            return await GenerateSql(csv);
        }

        private string CreateTable(CsvDataReader csv, string tableName)
        {
            if (!Options.CreateTable)
            {
                return string.Empty;
            }

            string objectId = tableName.Contains('#') ? $"tempdb..{tableName}" : tableName;

            var sql = $"IF OBJECT_ID('{objectId}', 'U') IS NOT NULL DROP TABLE {tableName};{Environment.NewLine}{Environment.NewLine}";

            sql += $"CREATE TABLE {tableName} ({Environment.NewLine}";

            var columns = Enumerable.Range(0, csv.FieldCount)
                .Select(i => $"  {EscapedName(csv.GetName(i), Options.AllowSpaces)} {SqlColumnType(csv.GetFieldTypeExtended(i))}");

            sql += string.Join(", " + Environment.NewLine, columns);

            sql += $");{Environment.NewLine}GO{Environment.NewLine}{Environment.NewLine}";

            return sql;
        }

        public string SqlColumnType(Type type)
        {
            if (type == typeof(int))
                return "INT";

            if (type == typeof(decimal))
                return $"DECIMAL({18 - Options.DecimalPlaces},{Options.DecimalPlaces})";

            if (type == typeof(DateTime) && Options.IncludeTime)
                return "DATETIME";

            if (type == typeof(DateTime))
                return "DATE";

            return $"VARCHAR({Options.StringSize})";
        }

        private static string EscapedName(string name, bool allowSpaces)
        {
            return $"[{(allowSpaces ? name : name.Replace(" ", ""))}]";
        }

        private async Task<string> GenerateSql(CsvDataReader csv)
        {
            var sql = new StringBuilder();

            var tableName = EscapedName(Options.TableName, Options.AllowSpaces);
            sql.Append(CreateTable(csv, tableName));

            if (Options.TruncateTable)
            {
                sql.Append($"TRUNCATE TABLE {tableName};{Environment.NewLine}{Environment.NewLine}");
            }

            var columns = Enumerable.Range(0, csv.FieldCount)
                .Select(i => EscapedName(csv.GetName(i), Options.AllowSpaces));

            var insertStatement = $"INSERT INTO {tableName} ({string.Join(", ", columns)}) ";
            var valueCollection = new List<string>();

            while (await csv.ReadAsync())
            {
                var values = Enumerable.Range(0, csv.FieldCount)
                    .Select(i => EscapeValue(csv.GetValue(i), csv.GetFieldTypeExtended(i)));

                valueCollection.Add("(" + string.Join(", ", values) + ")");
            }

            if (Options.BatchSize > 1)
            {
                insertStatement = $"{insertStatement}{Environment.NewLine}    ";

                for (var i = 0; i < valueCollection.Count; i += Options.BatchSize)
                {
                    var batch = valueCollection.Skip(i).Take(Options.BatchSize);
                    sql.AppendLine(insertStatement + string.Join($",{Environment.NewLine}    ", batch) + ";");
                    sql.AppendLine("GO" + Environment.NewLine);
                }
            }
            else
            {
                sql.AppendLine(string.Join($"{Environment.NewLine}", valueCollection.Select(s => insertStatement + s + ";")));
                sql.AppendLine();
            }

            if (Options.IndexColumn.HasValue)
            {
                var header = csv.GetName(Options.IndexColumn.Value + 1).Trim('[', ']');
                var indexType = Options.ClusteredIndex ? "CLUSTERED INDEX cx" : "NONCLUSTERED INDEX ix";

                sql.AppendLine($"CREATE {indexType}_{Options.TableName.Replace("#", "").Replace(" ", "")}_{header.Replace(" ", "")} ON {tableName} ([{header}]);");
                sql.AppendLine("GO");
            }

            if (Options.IdentityInsert)
            {
                sql.Insert(0, $"SET IDENTITY_INSERT {tableName} ON;{Environment.NewLine}{Environment.NewLine}");
                sql.AppendLine($"SET IDENTITY_INSERT {tableName} OFF;");

                if (Options.Reseed)
                {
                    sql.AppendLine($"{Environment.NewLine}DECLARE @Id INT = (SELECT MAX([{csv.GetName(0)}]) FROM {tableName});");
                    sql.AppendLine($"DBCC CHECKIDENT ('{tableName}', RESEED, @Id);");
                }
            }

            if (Options.NoCount)
            {
                sql.Insert(0, $"SET NOCOUNT ON;{Environment.NewLine}{Environment.NewLine}");
                sql.AppendLine($"SET NOCOUNT OFF;");
            }

            return sql.ToString();
        }
        
        private string EscapeValue(object value, Type type)
        {
            if (value == null)
                return "NULL";

            if (type == typeof(DateTime))
            {
                if ((DateTime)value != DateTime.MinValue)
                {
                    if (Options.IncludeTime)
                    {
                        return "'" + ((DateTime)value).ToString("yyyyMMdd hh:mm:ss tt") + "'";
                    }

                    return "'" + ((DateTime)value).ToString("yyyyMMdd") + "'";
                }

                return "NULL";
            }

            if (type == typeof(int) || type == typeof(decimal))
            {
                return value.ToString();
            }

            return "'" + value.ToString().Replace("'", "''") + "'";
        }
    }
}
