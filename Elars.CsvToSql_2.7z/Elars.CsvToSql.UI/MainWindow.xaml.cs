﻿using Elars.CsvToSql.Core;
using System;
using System.Windows;

namespace Elars.CsvToSql.UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeConverterProperties();
        }

        private void InitializeConverterProperties()
        {
            var converter = new Converter();
            txtTableName.Text = converter.TableName;
            txtBatchSize.Text = converter.BatchSize.ToString();
            chkAllowSpaces.IsChecked = converter.AllowSpaces;
            chkCreateTable.IsChecked = converter.CreateTable;
            chkReseed.IsChecked = converter.Reseed;
            chkNoCount.IsChecked = converter.NoCount;
            radClustered.IsChecked = converter.ClusteredIndex;
            radNonclustered.IsChecked = !converter.ClusteredIndex;
            chkIdentityInsert.IsChecked = converter.IdentityInsert;

            chkBatch_Click(null, null);
            chkIdentityInsert_Click(null, null); 
            chkCreateIndex_Click(null, null);
            txtSql_TextChanged(null, null);
        }

        private async void btnFromClipboard_Click(object sender, RoutedEventArgs e)
        {
            if (!Clipboard.ContainsText())
            {
                MessageBox.Show("Clipboard does not contain text");
                return;
            }

            try
            {
                var converter = NewConverter();
                txtSql.Text = await converter.ProcessString(Clipboard.GetText());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private Converter NewConverter()
        {
            var builder = new ConverterBuilder();

            builder.TableName(txtTableName.Text);
            builder.CreateTable(chkCreateTable.IsChecked.Value);
            builder.Reseed(chkReseed.IsChecked.Value);
            builder.NoCount(chkNoCount.IsChecked.Value);
            builder.AllowSpaces(chkAllowSpaces.IsChecked.Value);
            builder.ClusteredIndex(radClustered.IsChecked.Value);
            builder.IdentityInsert(chkIdentityInsert.IsChecked.Value);

            return builder.Build();
        }

        private void btnToClipboard_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(txtSql.Text);
        }

        private void chkBatch_Click(object sender, RoutedEventArgs e)
        {
            txtBatchSize.IsEnabled = chkBatch.IsChecked.Value;
        }

        private void chkIdentityInsert_Click(object sender, RoutedEventArgs e)
        {
            chkReseed.IsEnabled = chkIdentityInsert.IsChecked.Value;
        }

        private void chkCreateIndex_Click(object sender, RoutedEventArgs e)
        {
            txtIndexColumn.IsEnabled = chkCreateIndex.IsChecked.Value;
            radClustered.IsEnabled = chkCreateIndex.IsChecked.Value;
            radNonclustered.IsEnabled = chkCreateIndex.IsChecked.Value;
        }

        private void txtSql_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            btnSaveFile.IsEnabled = !string.IsNullOrEmpty(txtSql.Text);
            btnToClipboard.IsEnabled = !string.IsNullOrEmpty(txtSql.Text);
        }
    }
}
