﻿namespace Elars.CsvToSql.Core
{
    public interface IConverterBuilder
    {
        IConverterBuilder AllowSpaces(bool allowSpaces);
        IConverterBuilder BatchSize(int batchSize);
        IConverterBuilder ClusteredIndex(bool clusteredIndex);
        IConverterBuilder CreateTable(bool createTable);
        IConverterBuilder DecimalPlaces(int decimalPlaces);
        IConverterBuilder IdentityInsert(bool identityInsert);
        IConverterBuilder IncludeTime(bool includeTime);
        IConverterBuilder IndexColumn(int? indexColumn);
        IConverterBuilder NoCount(bool noCount);
        IConverterBuilder Reseed(bool reseed);
        IConverterBuilder StringSize(int stringSize);
        IConverterBuilder TableName(string tableName);
        IConverterBuilder TruncateTable(bool truncateTable);

        Converter Build();
    }

    public class ConverterBuilder : IConverterBuilder
    {
        Converter _converter = new Converter();

        public Converter Build()
        {
            return _converter;
        }

        public IConverterBuilder AllowSpaces(bool allowSpaces)
        {
            _converter.AllowSpaces = allowSpaces;
            return this;
        }

        public IConverterBuilder BatchSize(int batchSize)
        {
            _converter.BatchSize = batchSize;
            return this;
        }

        public IConverterBuilder ClusteredIndex(bool clusteredIndex)
        {
            _converter.ClusteredIndex = clusteredIndex;
            return this;
        }

        public IConverterBuilder CreateTable(bool createTable)
        {
            _converter.CreateTable = createTable;
            return this;
        }

        public IConverterBuilder DecimalPlaces(int decimalPlaces)
        {
            _converter.DecimalPlaces = decimalPlaces;
            return this;
        }

        public IConverterBuilder IdentityInsert(bool identityInsert)
        {
            _converter.IdentityInsert = identityInsert;
            return this;
        }

        public IConverterBuilder IncludeTime(bool includeTime)
        {
            _converter.IncludeTime = includeTime;
            return this;
        }

        public IConverterBuilder IndexColumn(int? indexColumn)
        {
            _converter.IndexColumn = indexColumn;
            return this;
        }

        public IConverterBuilder NoCount(bool noCount)
        {
            _converter.NoCount = noCount;
            return this;
        }

        public IConverterBuilder Reseed(bool reseed)
        {
            _converter.Reseed = reseed;
            return this;
        }

        public IConverterBuilder StringSize(int stringSize)
        {
            _converter.StringSize = stringSize;
            return this;
        }

        public IConverterBuilder TableName(string tableName)
        {
            _converter.TableName = tableName;
            return this;
        }

        public IConverterBuilder TruncateTable(bool truncateTable)
        {
            _converter.TruncateTable = truncateTable;
            return this;
        }
    }
}