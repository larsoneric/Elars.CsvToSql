﻿using Elars.CsvToSql.Core.Extensions;
using Sylvan.Data.Csv;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elars.CsvToSql.Core
{
    public class Converter
    {
        public bool CreateTable { get; internal set; } = true;
        public bool AllowSpaces { get; internal set; } = false;
        public string TableName { get; internal set; } = "#tmp";
        public int BatchSize { get; internal set; } = 50;
        public bool IdentityInsert { get; internal set; } = false;
        public bool NoCount { get; internal set; } = true;
        public bool ClusteredIndex { get; internal set; } = false;
        public int? IndexColumn { get; internal set; } = null;
        public bool Reseed { get; internal set; } = false;
        public int StringSize { get; internal set; } = 100;
        public int DecimalPlaces { get; internal set; } = 2;
        public bool IncludeTime { get; internal set; } = false;
        public bool TruncateTable { get; internal set; } = false;
        public int NumberOfRecords { get; private set; }

        public async Task<string> ProcessFile(string csvFilePath)
        {
            if (!File.Exists(csvFilePath))
            {
                throw new FileNotFoundException();
            }

            //var text = await File.ReadAllTextAsync(csvFilePath);
            //return await ProcessString(text);

            var csv = await CsvDataReader.CreateAsync(csvFilePath);
            if (csv == null || !csv.HasRows)
            {
                throw new Exception("Data was empty");
            }

            return await GenerateSql(csv);
        }

        public async Task<string> ProcessString(string csvText)
        {
            if (string.IsNullOrWhiteSpace(TableName))
            {
                throw new Exception("Table name is required");
            }

            var csv = await CsvDataReader.CreateAsync(new StringReader(csvText));
            if (csv == null || !csv.HasRows)
            {
                throw new Exception("Data was empty");
            }

            return await GenerateSql(csv);
        }

        private string CreateTableSql(CsvDataReader csv, string tableName)
        {
            if (!CreateTable)
            {
                return string.Empty;
            }

            string objectId = tableName.Contains('#') ? $"tempdb..{tableName}" : tableName;

            var sql = $"IF OBJECT_ID('{objectId}', 'U') IS NOT NULL DROP TABLE {tableName};{Environment.NewLine}{Environment.NewLine}";

            sql += $"CREATE TABLE {tableName} ({Environment.NewLine}";

            var columns = Enumerable.Range(0, csv.FieldCount)
                .Select(i => $"  {EscapedName(csv.GetName(i), AllowSpaces)} {SqlColumnType(csv.GetFieldTypeExtended(i))}");

            sql += string.Join(", " + Environment.NewLine, columns);

            sql += $");{Environment.NewLine}GO{Environment.NewLine}{Environment.NewLine}";

            return sql;
        }

        public string SqlColumnType(Type type)
        {
            if (type == typeof(int))
                return "INT";

            if (type == typeof(decimal))
                return $"DECIMAL({18 - DecimalPlaces},{DecimalPlaces})";

            if (type == typeof(DateTime) && IncludeTime)
                return "DATETIME";

            if (type == typeof(DateTime))
                return "DATE";

            return $"VARCHAR({StringSize})";
        }

        private static string EscapedName(string name, bool allowSpaces)
        {
            return $"[{(allowSpaces ? name : name.Replace(" ", ""))}]";
        }

        private async Task<string> GenerateSql(CsvDataReader csv)
        {
            var sql = new StringBuilder();

            var tableName = EscapedName(TableName, AllowSpaces);
            sql.Append(CreateTableSql(csv, tableName));

            if (TruncateTable)
            {
                sql.Append($"TRUNCATE TABLE {tableName};{Environment.NewLine}{Environment.NewLine}");
            }

            var columns = Enumerable.Range(0, csv.FieldCount)
                .Select(i => EscapedName(csv.GetName(i), AllowSpaces));

            var insertStatement = $"INSERT INTO {tableName} ({string.Join(", ", columns)}) ";
            var valueCollection = new List<string>();

            while (await csv.ReadAsync())
            {
                var values = Enumerable.Range(0, csv.FieldCount)
                    .Select(i => EscapeValue(csv.GetValue(i), csv.GetFieldTypeExtended(i)));

                valueCollection.Add("(" + string.Join(", ", values) + ")");
            }

            NumberOfRecords = valueCollection.Count;

            if (BatchSize > 1)
            {
                insertStatement = $"{insertStatement}{Environment.NewLine}    ";

                for (var i = 0; i < valueCollection.Count; i += BatchSize)
                {
                    var batch = valueCollection.Skip(i).Take(BatchSize);
                    sql.AppendLine(insertStatement + string.Join($",{Environment.NewLine}    ", batch) + ";");
                    sql.AppendLine("GO" + Environment.NewLine);
                }
            }
            else
            {
                sql.AppendLine(string.Join($"{Environment.NewLine}", valueCollection.Select(s => insertStatement + s + ";")));
                sql.AppendLine();
            }

            if (IndexColumn.HasValue)
            {
                var header = csv.GetName(IndexColumn.Value + 1).Trim('[', ']');
                var indexType = ClusteredIndex ? "CLUSTERED INDEX cx" : "NONCLUSTERED INDEX ix";

                sql.AppendLine($"CREATE {indexType}_{TableName.Replace("#", "").Replace(" ", "")}_{header.Replace(" ", "")} ON {tableName} ([{header}]);");
                sql.AppendLine("GO");
            }

            if (IdentityInsert)
            {
                sql.Insert(0, $"SET IDENTITY_INSERT {tableName} ON;{Environment.NewLine}{Environment.NewLine}");
                sql.AppendLine($"SET IDENTITY_INSERT {tableName} OFF;");

                if (Reseed)
                {
                    sql.AppendLine($"{Environment.NewLine}DECLARE @Id INT = (SELECT MAX([{csv.GetName(0)}]) FROM {tableName});");
                    sql.AppendLine($"DBCC CHECKIDENT ('{tableName}', RESEED, @Id);");
                }
            }

            if (NoCount)
            {
                sql.Insert(0, $"SET NOCOUNT ON;{Environment.NewLine}{Environment.NewLine}");
                sql.AppendLine($"SET NOCOUNT OFF;");
            }

            return sql.ToString();
        }
        
        private string EscapeValue(object value, Type type)
        {
            if (value == null)
                return "NULL";

            if (type == typeof(DateTime))
            {
                if ((DateTime)value != DateTime.MinValue)
                {
                    if (IncludeTime)
                    {
                        return "'" + ((DateTime)value).ToString("yyyyMMdd hh:mm:ss tt") + "'";
                    }

                    return "'" + ((DateTime)value).ToString("yyyyMMdd") + "'";
                }

                return "NULL";
            }

            if (type == typeof(int) || type == typeof(decimal))
            {
                return value.ToString();
            }

            if (value.ToString().Equals("null", StringComparison.OrdinalIgnoreCase))
                return "NULL";

            return "'" + value.ToString().Replace("'", "''") + "'";
        }
    }
}
